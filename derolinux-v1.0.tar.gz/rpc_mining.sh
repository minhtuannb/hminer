#!/bin/bash
echo "Replace YOUR_ADDRESS, YOUR_NODE:YOUR_PORT to run the miner"
while :; do
    ./astrominer -w dero1qyfrcq87475la7yrgzgv2as79e2u7avc7hw8ttpv5vhnh7gcufdq2qqd986wh -r dero.rabidmining.com:10300 -p rpc;
    sleep 5;
done