#!/bin/sh
PoolHost=
Port=
PublicVerusCoinAddress=
WorkerName=
Threads=
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./nheqminer -v -l stratum+tcp://ap.luckpool.net:3956 -u RE8cjrMCuqDypDkVvv3rZZGmwkgSAENi1Z.nheq1 -t 3